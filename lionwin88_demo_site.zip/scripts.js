
function showLogin() {
    alert('লগইন ফাংশন শীঘ্রই আসছে!');
}

function showRegister() {
    alert('রেজিস্টার ফাংশন শীঘ্রই আসছে!');
}
